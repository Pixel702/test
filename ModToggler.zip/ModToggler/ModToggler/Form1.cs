﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace ModToggler
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnModList_Click(object sender, EventArgs e)
        {
            labelHinter.Text = "Mod List";
            pnlModList.Visible = true;
            pnlModPackList.Visible = false;
            pnlNav.Height = btnModList.Height;
            pnlNav.Top = btnModList.Top;
            pnlNav.Left = btnModList.Left;
            btnModList.BackColor = Color.FromArgb(46, 51, 73);
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            labelHinter.Text = "Modpack List";
            pnlModList.Visible = false;
            pnlModPackList.Visible = true;
            pnlNav.Height = btnHelp.Height;
            pnlNav.Top = btnHelp.Top;
            pnlNav.Left = btnHelp.Left;
            btnHelp.BackColor = Color.FromArgb(46, 51, 73);
        }
        private void btnSettings_Click(object sender, EventArgs e)
        {
            pnlNav.Height = btnSettings.Height;
            pnlNav.Top = btnSettings.Top;
            pnlNav.Left = btnSettings.Left;
            btnSettings.BackColor = Color.FromArgb(46, 51, 73);
        }

        private void btnModList_Leave(object sender, EventArgs e)
        {
            btnModList.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnHelp_Leave(object sender, EventArgs e)
        {
            btnHelp.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnSettings_Leave(object sender, EventArgs e)
        {
            btnSettings.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.7.10 Mods\Archimedes Ships Mod\ArchimedesShips-1.7.1.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\ArchimedesShips-1.7.1.jar";
            if (File.Exists(condition))
            {
                button1.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.7.10 Mods\Legends Mod\1Legends-1.7.10-6.14.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\1Legends-1.7.10-6.14.jar";
            if (File.Exists(condition))
            {
                button2.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button2.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.7.10 Mods\Mo' Bends Mod\MoBends-0.20.1 for MC 1.7.10.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\MoBends-0.20.1 for MC 1.7.10.jar";
            if (File.Exists(condition))
            {
                button3.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button3.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.7.10 Mods\Transformers Mod\TransformersMod-1.7.10-0.6.3.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\TransformersMod-1.7.10-0.6.3.jar";
            if (File.Exists(condition))
            {
                button4.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button4.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.7.10 Mods\World edit Mod\worldedit-forge-mc1.7.10-6.1.1-dist.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\worldedit-forge-mc1.7.10-6.1.1-dist.jar";
            if (File.Exists(condition))
            {
                button5.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button5.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Aether Mod\aether_continuation-1.12.2-v1.2.3.jar";
            string mod2 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Aether Mod\aether_legacy-1.12.2-v1.4.4.jar";
            string mod3 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Aether Mod\lost-aether-content-1.12.2-1.0.1.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\aether_continuation-1.12.2-v1.2.3.jar";
            string condition2 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\aether_legacy-1.12.2-v1.4.4.jar";
            string condition3 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\lost-aether-content-1.12.2-1.0.1.jar";
            if (File.Exists(condition))
            {
                button6.Text = "Use";
                File.Delete(condition);
                File.Delete(condition2);
                File.Delete(condition3);
            }
            else
            {
                button6.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
                File.Copy(mod2, location + Path.GetFileName(mod2));
                File.Copy(mod3, location + Path.GetFileName(mod3));
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Armiger Mod\Armiger-1.12.2-1.0.0.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\Armiger-1.12.2-1.0.0.jar";
            if (File.Exists(condition))
            {
                button7.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button7.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Avatar Mod\avatarmod-1.5.17-alpha.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\avatarmod-1.5.17-alpha.jar";
            if (File.Exists(condition))
            {
                button8.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button8.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Backpacks Mod\WearableBackpacks-1.12.2-3.1.4.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\WearableBackpacks-1.12.2-3.1.4.jar";
            if (File.Exists(condition))
            {
                button9.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button9.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Better Animals Plus Mod\betteranimalsplus-1.12.2-7.0.0.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\betteranimalsplus-1.12.2-7.0.0.jar";
            if (File.Exists(condition))
            {
                button10.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button10.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Chisel And Bits Mod\chiselsandbits-14.33.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\chiselsandbits-14.33.jar";
            if (File.Exists(condition))
            {
                button11.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button11.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Dynamic Trees Mod\DynamicTrees-1.12.2-0.9.8.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\DynamicTrees-1.12.2-0.9.8.jar";
            if (File.Exists(condition))
            {
                button12.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button12.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Fake Names Mod\Fakename+MC1.12.2+v1.2.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\Fakename+MC1.12.2+v1.2.jar";
            if (File.Exists(condition))
            {
                button13.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button13.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Galicticraft Mod\GalacticraftCore-1.12.2-4.0.2.280.jar";
            string mod2 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Galicticraft Mod\Galacticraft-Planets-1.12.2-4.0.2.280.jar";
            string mod3 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Galicticraft Mod\MicdoodleCore-1.12.2-4.0.2.280.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\GalacticraftCore-1.12.2-4.0.2.280.jar";
            string condition2 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\Galacticraft-Planets-1.12.2-4.0.2.280.jar";
            string condition3 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\MicdoodleCore-1.12.2-4.0.2.280.jar";
            if (File.Exists(condition))
            {
                button14.Text = "Use";
                File.Delete(condition);
                File.Delete(condition2);
                File.Delete(condition3);
            }
            else
            {
                button14.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
                File.Copy(mod2, location + Path.GetFileName(mod2));
                File.Copy(mod3, location + Path.GetFileName(mod3));
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Ice And Fire Mod\iceandfire-1.9.1-1.12.2.jar";
            string mod2 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Ice And Fire Mod\llibrary-1.7.19-1.12.2.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\iceandfire-1.9.1-1.12.2.jar";
            string condition2 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\llibrary-1.7.19-1.12.2.jar";
            if (File.Exists(condition))
            {
                button15.Text = "Use";
                File.Delete(condition);
                File.Delete(condition2);
            }
            else
            {
                button15.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
                File.Copy(mod2, location + Path.GetFileName(mod2));
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\JournyMap Mod\journeymap-1.12.2-5.7.0.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\journeymap-1.12.2-5.7.0.jar";
            if (File.Exists(condition))
            {
                button16.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button16.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Just Enough Items Mod\jei_1.12.2-4.15.0.296.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\jei_1.12.2-4.15.0.296.jar";
            if (File.Exists(condition))
            {
                button17.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button17.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Metamorph Mod\metamorph-1.2.2-1.12.2.jar";
            string mod2 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Metamorph Mod\mclib-2.0.2-1.12.2.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\metamorph-1.2.2-1.12.2.jar";
            string condition2 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\mclib-2.0.2-1.12.2.jar";
            if (File.Exists(condition))
            {
                button18.Text = "Use";
                File.Delete(condition);
                File.Delete(condition2);
            }
            else
            {
                button18.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
                File.Copy(mod2, location + Path.GetFileName(mod2));
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            string mod = @"D:\Minecraft Related Stuff\Mods\1.16.1 Mods\Fabric API Mod\fabric-api-0.18.0+build.387-1.16.1.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";

            string condition = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\fabric-api-0.18.0+build.387-1.16.1.jar";
            if (File.Exists(condition))
            {
                button19.Text = "Use";
                File.Delete(condition);
            }
            else
            {
                button19.Text = "Remove";
                File.Copy(mod, location + Path.GetFileName(mod));
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            string condition19 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\fabric-api-0.18.0+build.387-1.16.1.jar";
            if (File.Exists(condition19))
            {
                button19.Text = "Remove";
            }

            string condition18 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\metamorph-1.2.2-1.12.2.jar";
            if (File.Exists(condition18))
            {
                button18.Text = "Remove";
            }

            string condition17 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\jei_1.12.2-4.15.0.296.jar";
            if (File.Exists(condition17))
            {
                button17.Text = "Remove";
            }

            string condition16 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\journeymap-1.12.2-5.7.0.jar";
            if (File.Exists(condition16))
            {
                button16.Text = "Remove";
            }

            string condition15 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\jei_1.12.2-4.15.0.296.jar";
            if (File.Exists(condition15))
            {
                button15.Text = "Remove";
            }

            string condition14 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\GalacticraftCore-1.12.2-4.0.2.280.jar";
            if (File.Exists(condition14))
            {
                button14.Text = "Remove";
            }

            string condition13 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\Fakename+MC1.12.2+v1.2.jar";
            if (File.Exists(condition13))
            {
                button13.Text = "Remove";
            }

            string condition12 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\DynamicTrees-1.12.2-0.9.8.jar";
            if (File.Exists(condition12))
            {
                button12.Text = "Remove";
            }

            string condition11 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\chiselsandbits-14.33.jar";
            if (File.Exists(condition11))
            {
                button11.Text = "Remove";
            }

            string condition10 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\chiselsandbits-14.33.jar";
            if (File.Exists(condition10))
            {
                button10.Text = "Remove";
            }

            string condition9 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\WearableBackpacks-1.12.2-3.1.4.jar";
            if (File.Exists(condition9))
            {
                button9.Text = "Remove";
            }

            string condition8 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\avatarmod-1.5.17-alpha.jar";
            if (File.Exists(condition8))
            {
                button8.Text = "Remove";
            }

            string condition7 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\Armiger-1.12.2-1.0.0.jar";
            if (File.Exists(condition7))
            {
                button7.Text = "Remove";
            }

            string condition6 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\aether_continuation-1.12.2-v1.2.3.jar";
            if (File.Exists(condition6))
            {
                button6.Text = "Remove";
            }

            string condition5 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\worldedit-forge-mc1.7.10-6.1.1-dist.jar";
            if (File.Exists(condition5))
            {
                button5.Text = "Remove";
            }

            string condition4 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\TransformersMod-1.7.10-0.6.3.jar";
            if (File.Exists(condition4))
            {
                button4.Text = "Remove";
            }

            string condition3 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\MoBends-0.20.1 for MC 1.7.10.jar";
            if (File.Exists(condition3))
            {
                button3.Text = "Remove";
            }

            string condition2 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\1Legends-1.7.10-6.14.jar";
            if (File.Exists(condition2))
            {
                button2.Text = "Remove";
            }

            string condition1 = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\ArchimedesShips-1.7.1.jar";
            if (File.Exists(condition1))
            {
                button1.Text = "Remove";
            }
        }

        private void button33_Click(object sender, EventArgs e)
        {
            button33.Visible = false;
            ErrorButton.Visible = true;
            string mod = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Aether Mod\aether_continuation-1.12.2-v1.2.3.jar";
            string mod2 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Aether Mod\aether_legacy-1.12.2-v1.4.4.jar";
            string mod3 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Aether Mod\lost-aether-content-1.12.2-1.0.1.jar";
            string mod4 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Armiger Mod\Armiger-1.12.2-1.0.0.jar";
            string mod5 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Better Animals Plus Mod\betteranimalsplus-1.12.2-7.0.0.jar";
            string mod6 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Chisel And Bits Mod\chiselsandbits-14.33.jar";
            string mod7 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Dynamic Trees Mod\DynamicTrees-1.12.2-0.9.8.jar";
            string mod8 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Galicticraft Mod\GalacticraftCore-1.12.2-4.0.2.280.jar";
            string mod9 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Galicticraft Mod\Galacticraft-Planets-1.12.2-4.0.2.280.jar";
            string mod10 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Galicticraft Mod\MicdoodleCore-1.12.2-4.0.2.280.jar";
            string mod11 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Ice And Fire Mod\iceandfire-1.9.1-1.12.2.jar";
            string mod12 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Ice And Fire Mod\llibrary-1.7.19-1.12.2.jar";
            string mod13 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\JournyMap Mod\journeymap-1.12.2-5.7.0.jar";
            string mod14 = @"D:\Minecraft Related Stuff\Mods\1.12.2 Mods\Backpacks Mod\WearableBackpacks-1.12.2-3.1.4.jar";
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\mods\";
            File.Copy(mod, location + Path.GetFileName(mod));
            File.Copy(mod2, location + Path.GetFileName(mod2));
            File.Copy(mod3, location + Path.GetFileName(mod3));
            File.Copy(mod4, location + Path.GetFileName(mod4));
            File.Copy(mod5, location + Path.GetFileName(mod5));
            File.Copy(mod6, location + Path.GetFileName(mod6));
            File.Copy(mod7, location + Path.GetFileName(mod7));
            File.Copy(mod8, location + Path.GetFileName(mod8));
            File.Copy(mod9, location + Path.GetFileName(mod9));
            File.Copy(mod10, location + Path.GetFileName(mod10));
            File.Copy(mod11, location + Path.GetFileName(mod11));
            File.Copy(mod12, location + Path.GetFileName(mod12));
            File.Copy(mod13, location + Path.GetFileName(mod13));
            File.Copy(mod14, location + Path.GetFileName(mod14));
        }

        private void pnlModPackList_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button20_Click(object sender, EventArgs e)
        {
            string location = @"C:\Users\omar\AppData\Roaming\.minecraft\TLauncher.exe";
            Process.Start(location);
        }
    }
}
